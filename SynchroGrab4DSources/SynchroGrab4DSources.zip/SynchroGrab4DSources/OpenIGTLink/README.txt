

This project provides an implementation of the OpenIGTLink protocol defined in

          http://wiki.na-mic.org/Wiki/index.php/OpenIGTLink


The code is distributed as open source under the new BSD liccense:

          http://www.opensource.org/licenses/bsd-license.php


